using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

/// <summary>
/// �κ��丮 ���� (���콺 �̺�Ʈ ����)
/// ��Ŭ��: �� ���� ǥ��
/// ��Ŭ��: ������ ���/����/���� ���
/// </summary>
public class InventorySlot : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    [Header("UI Elements")]
    public Image iconImage;
    public TextMeshProUGUI countText;
    public Image background;

    [Header("Colors")]
    public Color normalColor = new Color(0.2f, 0.2f, 0.3f, 1f);
    public Color hoverColor = new Color(0.3f, 0.3f, 0.4f, 1f);
    public Color emptyColor = new Color(0.1f, 0.1f, 0.15f, 0.5f);

    private InventoryItem item;
    private InventoryUI inventoryUI;

    public void Setup(InventoryItem item, InventoryUI ui)
    {
        this.item = item;
        this.inventoryUI = ui;

        if (iconImage != null)
        {
            if (item.icon != null)
            {
                iconImage.sprite = item.icon;
                iconImage.enabled = true;
                iconImage.color = Color.white;
            }
            else
            {
                iconImage.enabled = false;
            }
        }

        if (countText != null)
        {
            if (item.count > 1)
            {
                countText.text = item.count.ToString();
                countText.enabled = true;
            }
            else
            {
                countText.enabled = false;
            }
        }

        if (background != null)
        {
            background.color = normalColor;
        }
    }

    public void SetupEmpty(InventoryUI ui)
    {
        this.item = null;
        this.inventoryUI = ui;

        if (iconImage != null)
            iconImage.enabled = false;

        if (countText != null)
            countText.enabled = false;

        if (background != null)
            background.color = emptyColor;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (item == null) return;

        if (background != null)
            background.color = hoverColor;

        var itemData = ItemDatabase.Instance?.GetItemData(item.itemID);
        string displayName = (itemData != null && !string.IsNullOrEmpty(itemData.nameKey))
            ? LocalizationManager.T(itemData.nameKey)
            : item.itemName;
        inventoryUI.ShowTooltip(displayName, transform.position);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (item == null) return;

        if (background != null)
            background.color = normalColor;

        if (inventoryUI != null)
            inventoryUI.HideTooltip();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (item == null) return;

        if (eventData.button == PointerEventData.InputButton.Left)
        {
            if (inventoryUI != null)
                inventoryUI.ShowDetail(item);
        }
        else if (eventData.button == PointerEventData.InputButton.Right)
        {
            TryUseOrEquip();
        }
    }

    /// <summary>
    /// ������ Ÿ�Կ� ���� ��� �Ǵ� ����/���� ���
    /// </summary>
    private void TryUseOrEquip()
    {
        if (item == null) return;

        ItemData itemData = null;
        if (ItemDatabase.Instance != null)
            itemData = ItemDatabase.Instance.GetItemData(item.itemID);

        if (itemData == null)
        {
            Debug.LogWarning($"[InventorySlot] ItemData�� ã�� �� ����: ID={item.itemID}");
            return;
        }

        // === ����: ����� ȸ�� ===
        if (itemData.itemType == ItemType.Food)
        {
            UseFood(itemData);
            return;
        }

        // === �Һ� ������: HP ȸ�� ===
        if (itemData.itemType == ItemType.Consumable)
        {
            UseConsumable(itemData);
            return;
        }

        // === ���: ����/���� ��� ===
        if (itemData.IsEquipable)
        {
            ToggleEquipItem(itemData);
            return;
        }

        // === �� ���: ����/���� ��� ===
        if (itemData.IsColorModule)
        {
            ToggleColorModule(itemData);
            return;
        }

        Debug.Log($"[InventorySlot] {item.itemName}��(��) ����� �� �����ϴ�.");
    }

    // ============================================
    // ���� ���
    // ============================================
    private void UseFood(ItemData itemData)
    {
        PlayerStats stats = FindObjectOfType<PlayerStats>();
        if (stats == null) return;

        if (stats.hunger >= stats.maxHunger)
        {
            Debug.Log("[InventorySlot] ������� �̹� ���� á���ϴ�.");
            return;
        }

        stats.hunger = Mathf.Min(stats.maxHunger, stats.hunger + itemData.hungerRestore);

        if (itemData.fatigueRestore > 0)
            stats.fatigue = Mathf.Min(stats.maxFatigue, stats.fatigue + itemData.fatigueRestore);

        stats.ClampAll();

        InventoryManager.Instance?.RemoveItem(item.itemID, 1);
        Debug.Log($"[InventorySlot] {item.itemName} ���! ����� +{itemData.hungerRestore}");
        inventoryUI?.RefreshUI();
    }

    // ============================================
    // �Һ� ������ ��� (HP ȸ��)
    // ============================================
    private void UseConsumable(ItemData itemData)
    {
        PlayerStats stats = FindObjectOfType<PlayerStats>();
        if (stats == null) return;

        if (itemData.hpRestore > 0)
        {
            if (stats.hp >= stats.maxHP)
            {
                Debug.Log("[InventorySlot] HP�� �̹� ���� á���ϴ�.");
                return;
            }
            stats.Heal(itemData.hpRestore);
        }

        if (itemData.fatigueRestore > 0)
            stats.fatigue = Mathf.Min(stats.maxFatigue, stats.fatigue + itemData.fatigueRestore);

        if (itemData.hungerRestore > 0)
            stats.hunger = Mathf.Min(stats.maxHunger, stats.hunger + itemData.hungerRestore);

        stats.ClampAll();

        InventoryManager.Instance?.RemoveItem(item.itemID, 1);
        Debug.Log($"[InventorySlot] {item.itemName} ���! HP +{itemData.hpRestore}");
        inventoryUI?.RefreshUI();
    }

    // ============================================
    // ��� ����: �κ��丮���� ���� �� ��� �������� �̵�
    // ============================================
    private void ToggleEquipItem(ItemData itemData)
    {
        EquipmentManager equipMgr = EquipmentManager.Instance;
        if (equipMgr == null)
        {
            Debug.LogWarning("[InventorySlot] EquipmentManager�� ã�� �� �����ϴ�.");
            return;
        }

        // �� ���Կ� ����
        bool success = equipMgr.AutoEquip(itemData.equipmentDefinition);
        if (success)
        {
            // �κ��丮���� ����
            InventoryManager.Instance?.RemoveItem(item.itemID, 1);
            Debug.Log($"[InventorySlot] {item.itemName} ����! (�κ��丮 �� ��� ����)");
        }
        else
        {
            Debug.Log("[InventorySlot] �� ��� ������ �����ϴ�!");
        }

        inventoryUI?.RefreshUI();
    }

    // ============================================
    // �� ��� ����: �κ��丮���� ���� �� ��� �������� �̵�
    // ============================================
    private void ToggleColorModule(ItemData itemData)
    {
        ColorModuleSlots moduleSlots = ColorModuleSlots.Instance;
        if (moduleSlots == null)
        {
            Debug.LogWarning("[InventorySlot] ColorModuleSlots�� ã�� �� �����ϴ�.");
            return;
        }

        // �� ���Կ� ����
        ColorModuleInstance moduleInstance = new ColorModuleInstance(itemData.colorModuleDefinition);
        bool equipped = false;

        for (int i = 0; i < ColorModuleSlots.MAX_SLOTS; i++)
        {
            if (moduleSlots.GetSlot(i) == null)
            {
                moduleSlots.Equip(i, moduleInstance);
                // �κ��丮���� ����
                InventoryManager.Instance?.RemoveItem(item.itemID, 1);
                Debug.Log($"[InventorySlot] {item.itemName} ��� ����! (�κ��丮 �� ���� {i})");
                equipped = true;
                break;
            }
        }

        if (!equipped)
            Debug.Log("[InventorySlot] �� ��� ������ �����ϴ�! (�ִ� 5��)");

        inventoryUI?.RefreshUI();
    }
}