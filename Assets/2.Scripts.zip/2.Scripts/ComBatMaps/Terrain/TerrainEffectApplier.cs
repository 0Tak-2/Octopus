using UnityEngine;

public class TerrainEffectApplier : MonoBehaviour
{
    private CombatUnitStats _stats;

    public string CurrentTerrainName { get; private set; } = "Empty";

    private void Awake()
    {
        _stats = GetComponent<CombatUnitStats>();
        if (_stats == null)
            Debug.LogError($"{name}: CombatUnitStats�� �ʿ��մϴ�.");
    }

    public void ApplyFromCombatTileTypeName(string combatTileTypeName)
    {
        if (_stats == null) return;

        if (string.IsNullOrEmpty(combatTileTypeName))
            combatTileTypeName = "Empty";

        if (CurrentTerrainName == combatTileTypeName) return;

        CurrentTerrainName = combatTileTypeName;

        _stats.ClearTerrainBonuses();

        // CombatTileType enum ��� �̸��� ���ڿ��� ��Ī(������ ����)
        switch (combatTileTypeName)
        {
            case "Seaweed":
                _stats.evasionBonus = 0.40f;
                break;

            case "Hill":
                _stats.rangeBonus = 1;
                break;

            case "Current":
                _stats.freeMovesBonus = 1;
                break;

            // Wall/Empty/��Ÿ�� ���ʽ� ����
            default:
                break;
        }
    }
}
