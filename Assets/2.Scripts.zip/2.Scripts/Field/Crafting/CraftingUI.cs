using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

/// <summary>
/// ���� UI ����
/// </summary>
public class CraftingUI : MonoBehaviour
{
    [Header("UI References")]
    public GameObject craftingPanel; // ���� UI �г�
    public Transform recipeGridParent; // ������ �׸��� �θ�
    public GameObject recipeSlotPrefab; // ������ ���� ������

    [Header("Tooltip")]
    public GameObject recipeTooltip; // ������ ����
    public TextMeshProUGUI tooltipText; // ���� �ؽ�Ʈ

    [Header("Category Buttons")]
    public Button btnAll;
    public Button btnTool;
    public Button btnBuilding;
    public Button btnStorage;

    [Header("Button Colors")]
    public Color selectedColor = new Color(0.3f, 0.5f, 0.7f);
    public Color normalColor = new Color(0.2f, 0.2f, 0.3f);

    private RecipeCategory currentCategory = RecipeCategory.All;
    private List<GameObject> recipeSlots = new List<GameObject>();

    private void Start()
    {
        if (craftingPanel != null)
            craftingPanel.SetActive(false);

        // ���� �����
        if (recipeTooltip != null)
            recipeTooltip.SetActive(false);

        // ī�װ��� ��ư ����
        if (btnAll != null) btnAll.onClick.AddListener(() => SelectCategory(RecipeCategory.All));
        if (btnTool != null) btnTool.onClick.AddListener(() => SelectCategory(RecipeCategory.Tool));
        if (btnBuilding != null) btnBuilding.onClick.AddListener(() => SelectCategory(RecipeCategory.Building));
        if (btnStorage != null) btnStorage.onClick.AddListener(() => SelectCategory(RecipeCategory.Storage));

        // �ʱ� ī�װ��� ���� ���� (��ü ���� ����)
        UpdateCategoryButtons();
    }

    /// <summary>
    /// ���� UI ����
    /// </summary>
    public void OpenCrafting()
    {
        Debug.Log("[CraftingUI] OpenCrafting called!");

        if (craftingPanel != null)
        {
            // �̹� ���������� ����
            if (craftingPanel.activeSelf)
            {
                Debug.Log("[CraftingUI] Already open, ignoring...");
                return;
            }

            Debug.Log("[CraftingUI] Setting panel active...");
            craftingPanel.SetActive(true);

            // Coroutine ��� (Invoke�� ��Ȱ��ȭ�� ������Ʈ���� �۵� �� ��)
            StartCoroutine(RefreshAfterOpenCoroutine());
        }
        else
        {
            Debug.LogError("[CraftingUI] CraftingPanel is null!");
        }
    }

    /// <summary>
    /// ���� �� ���� (Coroutine)
    /// </summary>
    private System.Collections.IEnumerator RefreshAfterOpenCoroutine()
    {
        yield return new WaitForSeconds(0.05f);
        RefreshAfterOpen();
    }

    /// <summary>
    /// ���� �� ����
    /// </summary>
    private void RefreshAfterOpen()
    {
        Debug.Log("[CraftingUI] RefreshAfterOpen called!");
        if (craftingPanel != null && craftingPanel.activeSelf)
        {
            UpdateCategoryButtons();
            RefreshRecipes();
        }
    }

    /// <summary>
    /// ���� UI �ݱ�
    /// </summary>
    public void CloseCrafting()
    {
        if (craftingPanel != null)
            craftingPanel.SetActive(false);
    }

    /// <summary>
    /// ���� UI�� �����ִ��� Ȯ��
    /// </summary>
    public bool IsOpen()
    {
        return craftingPanel != null && craftingPanel.activeSelf;
    }

    /// <summary>
    /// ī�װ��� ����
    /// </summary>
    private void SelectCategory(RecipeCategory category)
    {
        currentCategory = category;
        UpdateCategoryButtons();
        RefreshRecipes();
    }

    /// <summary>
    /// ī�װ��� ��ư ���� ������Ʈ
    /// </summary>
    private void UpdateCategoryButtons()
    {
        if (btnAll != null)
            btnAll.GetComponent<Image>().color = (currentCategory == RecipeCategory.All) ? selectedColor : normalColor;
        if (btnTool != null)
            btnTool.GetComponent<Image>().color = (currentCategory == RecipeCategory.Tool) ? selectedColor : normalColor;
        if (btnBuilding != null)
            btnBuilding.GetComponent<Image>().color = (currentCategory == RecipeCategory.Building) ? selectedColor : normalColor;
        if (btnStorage != null)
            btnStorage.GetComponent<Image>().color = (currentCategory == RecipeCategory.Storage) ? selectedColor : normalColor;
    }

    /// <summary>
    /// ������ ��� ����
    /// </summary>
    public void RefreshRecipes()
    {
        // ���� ���� ����
        foreach (var slot in recipeSlots)
        {
            if (slot != null)
                Destroy(slot);
        }
        recipeSlots.Clear();

        if (CraftingManager.Instance == null)
        {
            Debug.LogError("[CraftingUI] CraftingManager.Instance is null!");
            return;
        }

        // ������ ��������
        var allRecipes = CraftingManager.Instance.GetRecipesByCategory(currentCategory);
        var craftableRecipes = CraftingManager.Instance.GetCraftableRecipes(currentCategory);

        // ���� ������ �� ���� (���� ��)
        foreach (var recipe in craftableRecipes)
        {
            CreateRecipeSlot(recipe, true);
        }

        // ���� �Ұ����� �� ���߿�
        foreach (var recipe in allRecipes)
        {
            if (!craftableRecipes.Contains(recipe))
            {
                CreateRecipeSlot(recipe, false);
            }
        }

        Debug.Log($"[CraftingUI] Displayed {allRecipes.Count} recipes ({craftableRecipes.Count} craftable)");
    }

    /// <summary>
    /// ������ ���� ����
    /// </summary>
    private void CreateRecipeSlot(CraftingRecipe recipe, bool canCraft)
    {
        if (recipeSlotPrefab == null || recipeGridParent == null)
        {
            Debug.LogError("[CraftingUI] Prefab or parent is null!");
            return;
        }

        GameObject slotObj = Instantiate(recipeSlotPrefab, recipeGridParent);
        RecipeSlot slot = slotObj.GetComponent<RecipeSlot>();

        if (slot != null)
        {
            slot.Setup(recipe, canCraft, this);
            recipeSlots.Add(slotObj);
        }
    }

    /// <summary>
    /// ������ ���� ǥ��
    /// </summary>
    public void ShowRecipeTooltip(string text)
    {
        if (recipeTooltip != null && tooltipText != null)
        {
            tooltipText.text = text;
            recipeTooltip.SetActive(true);

            // ���콺 ��ġ�� ǥ��
            Vector3 mousePos = Input.mousePosition;
            recipeTooltip.transform.position = mousePos + new Vector3(10f, -10f, 0f);
        }
    }

    /// <summary>
    /// ������ ���� �����
    /// </summary>
    public void HideRecipeTooltip()
    {
        if (recipeTooltip != null)
        {
            recipeTooltip.SetActive(false);
        }
    }

    /// <summary>
    /// ������ ���� �õ�
    /// </summary>
    public void TryCraft(CraftingRecipe recipe)
    {
        if (CraftingManager.Instance.CraftItem(recipe))
        {
            Debug.Log($"[CraftingUI] Successfully crafted!");
            RefreshRecipes(); // ���� UI ����

            // �κ��丮 UI�� ����
            InventoryUI inventoryUI = FindObjectOfType<InventoryUI>();
            if (inventoryUI != null)
            {
                inventoryUI.RefreshUI();
            }
        }
        else
        {
            Debug.LogWarning($"[CraftingUI] Failed to craft");
        }
    }
}