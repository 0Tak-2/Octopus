using UnityEngine;

/// <summary>
/// �ٴڿ� ������ ������
/// </summary>
public class DroppedItem : MonoBehaviour
{
    [Header("Item Data")]
    public string itemName = "Seaweed";
    public int itemID = 1; // 1 = ����
    public int count = 1;

    [Header("Visual")]
    public float floatSpeed = 0.5f;
    public float floatHeight = 0.1f;

    private Vector3 startPosition;
    private float floatTimer = 0f;

    private void Start()
    {
        startPosition = transform.position;
    }

    private void Update()
    {
        // ���ٴϴ� ȿ��
        floatTimer += Time.deltaTime * floatSpeed;
        float offset = Mathf.Sin(floatTimer) * floatHeight;
        transform.position = startPosition + new Vector3(0, offset, 0);
    }

    /// <summary>
    /// ������ �ݱ�
    /// </summary>
    public void Pickup(Vector3 playerPosition)
    {
        // �κ��丮�� �߰�
        InventoryManager inventory = FindObjectOfType<InventoryManager>();
        if (inventory != null)
        {
            inventory.AddItem(itemID, itemName, count, playerPosition);
        }

        // ������ ����
        Destroy(gameObject);
    }
}