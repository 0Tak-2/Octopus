using System.Collections;
using UnityEngine;

/// <summary>
/// �߻�ü - ������ �÷��̾�� ���ư�
/// </summary>
public class Projectile : MonoBehaviour
{
    [Header("Movement")]
    public float speed = 10f;
    public bool rotateTowardsTarget = true; // ȭ�� ���� ���� true

    [Header("Lifetime")]
    public float maxLifetime = 3f; // 3�� �� �ڵ� ����

    private Vector3 targetPosition;
    private bool isFlying = false;
    private float lifetime = 0f;

    /// <summary>
    /// �߻�ü �߻�
    /// </summary>
    public void Launch(Vector3 from, Vector3 to)
    {
        transform.position = from;
        targetPosition = to;
        isFlying = true;

        // ���� ȸ�� (ȭ�� ��)
        if (rotateTowardsTarget)
        {
            Vector3 direction = (to - from).normalized;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0, 0, angle);
        }
    }

    private void Update()
    {
        if (!isFlying) return;

        lifetime += Time.deltaTime;

        // ���� üũ
        if (lifetime >= maxLifetime)
        {
            Destroy(gameObject);
            return;
        }

        // ��ǥ�� �̵�
        transform.position = Vector3.MoveTowards(
            transform.position,
            targetPosition,
            speed * Time.deltaTime
        );

        // ���� Ȯ��
        if (Vector3.Distance(transform.position, targetPosition) < 0.1f)
        {
            // ����! ����
            Destroy(gameObject);
        }
    }
}