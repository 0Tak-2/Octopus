using UnityEngine;

/// <summary>
/// �÷��̾ �ﰢ ���󰡴� ī�޶�
/// </summary>
public class SnapCamera : MonoBehaviour
{
    [Header("Target")]
    public Transform target; // �÷��̾�

    [Header("Offset")]
    public Vector3 offset = new Vector3(0f, 0f, -10f);

    [Header("Settings")]
    public bool snapInstantly = true; // �ﰢ �̵�
    public float smoothSpeed = 0.1f; // �ε巯�� (snapInstantly = false�� ��)

    private void LateUpdate()
    {
        if (target == null) return;

        Vector3 targetPosition = target.position + offset;

        if (snapInstantly)
        {
            // �ﰢ �̵� (���� ����)
            transform.position = targetPosition;
        }
        else
        {
            // �ణ �ε巴��
            transform.position = Vector3.Lerp(
                transform.position,
                targetPosition,
                smoothSpeed
            );
        }
    }
}