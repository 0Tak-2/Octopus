using UnityEngine;
using UnityEditor;
using System.Linq;

/// <summary>
/// LocalizationTable�� Ŀ���� ������.
/// �˻�, ī�װ��� ����, �׸� �� ǥ�� �� ���� ����� �����մϴ�.
/// ��ġ: Assets/Editor/LocalizationTableEditor.cs
/// </summary>
[CustomEditor(typeof(LocalizationTable))]
public class LocalizationTableEditor : Editor
{
    private string searchFilter = "";
    private string categoryFilter = "All";
    private bool showAddSection = false;
    private string newKey = "";
    private string newValue = "";
    private Vector2 scrollPos;

    // ī�װ��� ��� (Ű ���ξ� ���)
    private static readonly string[] categories = new string[]
    {
        "All", "PASSIVE_", "SKILL_", "EQUIP_", "ENEMY_",
        "ITEM_", "STAT_", "STATUS_", "UI_", "SYS_", "TUT_", "FOCUS_", "MODULE_"
    };

    public override void OnInspectorGUI()
    {
        LocalizationTable table = (LocalizationTable)target;

        // ��� ����
        EditorGUILayout.PropertyField(serializedObject.FindProperty("language"));
        EditorGUILayout.Space(5);

        // ���
        int totalCount = table.entries.Count;
        EditorGUILayout.HelpBox($"�� {totalCount}�� �׸�", MessageType.Info);

        EditorGUILayout.Space(5);

        // ���� �˻� �� ����
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("�˻�", GUILayout.Width(40));
        searchFilter = EditorGUILayout.TextField(searchFilter);
        if (GUILayout.Button("X", GUILayout.Width(25)))
            searchFilter = "";
        EditorGUILayout.EndHorizontal();

        // ���� ī�װ��� ���� ����
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("ī�װ���", GUILayout.Width(55));
        int catIndex = System.Array.IndexOf(categories, categoryFilter);
        if (catIndex < 0) catIndex = 0;
        catIndex = EditorGUILayout.Popup(catIndex, categories);
        categoryFilter = categories[catIndex];
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space(5);

        // ���� �׸� �߰� ����
        showAddSection = EditorGUILayout.Foldout(showAddSection, "�� �׸� �߰�", true);
        if (showAddSection)
        {
            EditorGUI.indentLevel++;
            newKey = EditorGUILayout.TextField("Key", newKey);
            newValue = EditorGUILayout.TextField("Value", newValue);

            if (GUILayout.Button("�߰�"))
            {
                if (!string.IsNullOrEmpty(newKey))
                {
                    bool exists = table.entries.Any(e => e.key == newKey);
                    if (exists)
                    {
                        EditorUtility.DisplayDialog("�ߺ� Ű", $"'{newKey}' Ű�� �̹� �����մϴ�.", "Ȯ��");
                    }
                    else
                    {
                        Undo.RecordObject(table, "Add Localization Entry");
                        table.entries.Add(new LocalizationEntry { key = newKey, value = newValue });
                        newKey = "";
                        newValue = "";
                        EditorUtility.SetDirty(table);
                    }
                }
            }
            EditorGUI.indentLevel--;
        }

        EditorGUILayout.Space(10);

        // ���� �׸� ����Ʈ ����
        serializedObject.Update();
        SerializedProperty entriesProp = serializedObject.FindProperty("entries");

        scrollPos = EditorGUILayout.BeginScrollView(scrollPos, GUILayout.MaxHeight(600));

        int visibleCount = 0;
        for (int i = 0; i < entriesProp.arraySize; i++)
        {
            SerializedProperty entry = entriesProp.GetArrayElementAtIndex(i);
            string key = entry.FindPropertyRelative("key").stringValue;
            string value = entry.FindPropertyRelative("value").stringValue;

            // ���� ����
            if (categoryFilter != "All" && !key.StartsWith(categoryFilter))
                continue;
            if (!string.IsNullOrEmpty(searchFilter))
            {
                string lowerSearch = searchFilter.ToLower();
                if (!key.ToLower().Contains(lowerSearch) && !value.ToLower().Contains(lowerSearch))
                    continue;
            }

            visibleCount++;

            EditorGUILayout.BeginHorizontal();

            // Ű (�б� ���� ��Ÿ��)
            EditorGUILayout.LabelField(key, EditorStyles.boldLabel, GUILayout.Width(260));

            // �� (���� ����)
            SerializedProperty valueProp = entry.FindPropertyRelative("value");
            valueProp.stringValue = EditorGUILayout.TextField(valueProp.stringValue);

            // ���� ��ư
            if (GUILayout.Button("X", GUILayout.Width(25)))
            {
                if (EditorUtility.DisplayDialog("���� Ȯ��", $"'{key}' �׸��� �����Ͻðڽ��ϱ�?", "����", "���"))
                {
                    entriesProp.DeleteArrayElementAtIndex(i);
                    i--;
                }
            }

            EditorGUILayout.EndHorizontal();
        }

        EditorGUILayout.EndScrollView();

        if (visibleCount == 0)
            EditorGUILayout.HelpBox("���Ϳ� ��ġ�ϴ� �׸��� �����ϴ�.", MessageType.Warning);
        else if (visibleCount < totalCount)
            EditorGUILayout.LabelField($"ǥ��: {visibleCount} / {totalCount}", EditorStyles.miniLabel);

        serializedObject.ApplyModifiedProperties();

        EditorGUILayout.Space(10);

        // ���� ���� ��ư ����
        if (GUILayout.Button("Ű �̸��� ����"))
        {
            Undo.RecordObject(table, "Sort Localization Entries");
            table.entries.Sort((a, b) => string.Compare(a.key, b.key, System.StringComparison.Ordinal));
            EditorUtility.SetDirty(table);
        }
    }
}