using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

/// <summary>
/// �ʵ� �� ��� ��ų �� UI
/// ������ ��ų�� ���������� ǥ��, ��ٿ� ǥ��, ����Ű/Ŭ������ ����
/// </summary>
public class FieldColorSkillBarUI : MonoBehaviour
{
    [Header("References")]
    public FieldColorSkillCaster caster;
    public ColorModuleSlots moduleSlots;

    [Header("UI Container")]
    public Transform slotContainer;
    public GameObject slotPrefab;

    [Header("Selected Info")]
    public TMP_Text selectedSkillText;

    private List<FieldColorSkillSlot> _slots = new List<FieldColorSkillSlot>();

    private void Start()
    {
        if (caster == null) caster = FindObjectOfType<FieldColorSkillCaster>();
        if (moduleSlots == null) moduleSlots = ColorModuleSlots.Instance;

        if (caster != null)
        {
            caster.OnSelectedChanged += HandleSelectedChanged;
            caster.OnCooldownChanged += RefreshAll;
            caster.OnArmedChanged += HandleArmedChanged;
        }

        if (moduleSlots != null)
            moduleSlots.OnSlotsChanged += RefreshAll;

        RefreshAll();
    }

    private void OnDestroy()
    {
        if (caster != null)
        {
            caster.OnSelectedChanged -= HandleSelectedChanged;
            caster.OnCooldownChanged -= RefreshAll;
            caster.OnArmedChanged -= HandleArmedChanged;
        }

        if (moduleSlots != null)
            moduleSlots.OnSlotsChanged -= RefreshAll;
    }

    /// <summary>
    /// ��ü ���� ����
    /// </summary>
    public void RefreshAll()
    {
        // ���� ���� ����
        foreach (var slot in _slots)
        {
            if (slot != null && slot.gameObject != null)
                Destroy(slot.gameObject);
        }
        _slots.Clear();

        if (moduleSlots == null || slotContainer == null || slotPrefab == null) return;

        // ������ ��ų�� ǥ��
        var skills = moduleSlots.GetEquippedSkills();
        for (int i = 0; i < skills.Count; i++)
        {
            CreateSlot(i, skills[i]);
        }

        UpdateSelectedText();
    }

    private void CreateSlot(int index, ColorModuleInstance module)
    {
        var go = Instantiate(slotPrefab, slotContainer);
        var slot = go.GetComponent<FieldColorSkillSlot>();

        if (slot == null)
        {
            slot = go.AddComponent<FieldColorSkillSlot>();
        }

        int cooldown = caster != null ? caster.GetCooldownRemaining(index) : 0;
        bool isSelected = caster != null && caster.IsArmed && caster.SelectedSlotIndex == index;

        slot.Setup(index, module, cooldown, isSelected, OnSlotClicked);
        _slots.Add(slot);
    }

    private void OnSlotClicked(int index)
    {
        if (caster == null || moduleSlots == null) return;

        var skills = moduleSlots.GetEquippedSkills();
        if (index < 0 || index >= skills.Count) return;

        caster.SelectSkill(index, skills[index]);
    }

    private void HandleSelectedChanged(int index)
    {
        RefreshSlotStates();
        UpdateSelectedText();
    }

    private void HandleArmedChanged(bool armed)
    {
        RefreshSlotStates();
        UpdateSelectedText();
    }

    private void RefreshSlotStates()
    {
        for (int i = 0; i < _slots.Count; i++)
        {
            if (_slots[i] == null) continue;

            int cooldown = caster != null ? caster.GetCooldownRemaining(i) : 0;
            bool isSelected = caster != null && caster.IsArmed && caster.SelectedSlotIndex == i;

            _slots[i].UpdateState(cooldown, isSelected);
        }
    }

    private void UpdateSelectedText()
    {
        if (selectedSkillText == null) return;

        if (caster != null && caster.IsArmed && caster.SelectedSkill != null)
        {
            string hint = caster.SelectedSkill.Skill == SkillID.Blue_StretchTentacle
                ? "�̵��� ��ġ�� Ŭ��"
                : "���� Ŭ���Ͽ� ����";
            selectedSkillText.text = $"{caster.SelectedSkill.Name} - {hint} (��Ŭ��/ESC ���)";
        }
        else
        {
            selectedSkillText.text = "";
        }
    }
}

/// <summary>
/// �ʵ� ��ų���� ���� ����
/// </summary>
public class FieldColorSkillSlot : MonoBehaviour
{
    [Header("UI Elements")]
    public Image iconImage;
    public Image backgroundImage;
    public TMP_Text hotkeyText;
    public TMP_Text cooldownText;
    public Image cooldownOverlay;
    public Image selectionBorder;

    [Header("Colors")]
    public Color readyColor = new Color(1f, 1f, 1f, 1f);
    public Color cooldownColor = new Color(0.4f, 0.4f, 0.4f, 0.8f);
    public Color selectedBorderColor = new Color(1f, 1f, 0f, 1f);

    private int _index;
    private ColorModuleInstance _module;
    private System.Action<int> _onClick;

    public void Setup(int index, ColorModuleInstance module, int cooldown, bool isSelected, System.Action<int> onClick)
    {
        _index = index;
        _module = module;
        _onClick = onClick;

        // ������
        if (iconImage != null)
        {
            if (module.Icon != null)
            {
                iconImage.sprite = module.Icon;
                iconImage.enabled = true;
            }
            else
            {
                iconImage.enabled = false;
            }
        }

        // ���� (����)
        if (backgroundImage != null)
        {
            backgroundImage.color = module.Color switch
            {
                ColorType.Red => new Color(0.8f, 0.2f, 0.2f, 0.6f),
                ColorType.Blue => new Color(0.2f, 0.3f, 0.8f, 0.6f),
                ColorType.Black => new Color(0.2f, 0.2f, 0.2f, 0.6f),
                _ => new Color(0.3f, 0.3f, 0.3f, 0.6f)
            };
        }

        // ����Ű ǥ��
        if (hotkeyText != null)
            hotkeyText.text = $"{index + 1}";

        // ��ư Ŭ��
        var button = GetComponent<Button>();
        if (button == null) button = gameObject.AddComponent<Button>();
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(() => _onClick?.Invoke(_index));

        UpdateState(cooldown, isSelected);
    }

    public void UpdateState(int cooldown, bool isSelected)
    {
        // ��ٿ� ǥ��
        bool onCooldown = cooldown > 0;

        if (cooldownText != null)
        {
            cooldownText.text = onCooldown ? $"{cooldown}" : "";
            cooldownText.enabled = onCooldown;
        }

        if (cooldownOverlay != null)
        {
            cooldownOverlay.enabled = onCooldown;
        }

        // ������ ���
        if (iconImage != null)
        {
            iconImage.color = onCooldown ? cooldownColor : readyColor;
        }

        // ���� �׵θ�
        if (selectionBorder != null)
        {
            selectionBorder.enabled = isSelected;
            if (isSelected)
                selectionBorder.color = selectedBorderColor;
        }

        // ��ư Ȱ��ȭ
        var button = GetComponent<Button>();
        if (button != null)
            button.interactable = !onCooldown;
    }
}