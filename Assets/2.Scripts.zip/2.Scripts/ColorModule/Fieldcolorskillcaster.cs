using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// �ʵ忡�� �� ��� ��ų ���
/// ���������� ������ ��ų ȿ��, �� AP ��� 1�� 1�ൿ
/// ����Ű�� ��ų ���� �� ���콺 Ŭ������ ��� ����
/// </summary>
public class FieldColorSkillCaster : MonoBehaviour
{
    [Header("Refs")]
    public GridBoard gridBoard;
    public FieldTimeManager fieldTimeManager;
    public PlayerStats playerStats;
    public ColorModuleSlots moduleSlots;

    [Header("Targeting")]
    public Camera worldCamera;
    [Tooltip("�� ������ ����� ���̾�")]
    public LayerMask enemyQueryLayerMask = ~0;
    public float cellOverlapRadius = 0.18f;

    [Header("Rules")]
    public bool requireLoS = true;

    [Header("Cooldown")]
    [Tooltip("AP 2 ��ų�� �ʵ� ��ٿ� (��)")]
    public int ap2SkillCooldown = 1;

    [Header("Cast Visual")]
    public float castDashDuration = 0.06f;
    public float castReturnDuration = 0.05f;
    public float castDashFraction = 0.55f;

    [Header("Debug")]
    public bool log = true;

    // ===== State =====
    private ColorModuleInstance _selectedSkill;
    private int _selectedSlotIndex = -1;
    private bool _armed = false;
    private bool _isCasting = false;

    // ���� �ε��� => ��ٿ� ���� ��
    private readonly Dictionary<int, int> _cooldownRemaining = new();

    // ===== Events (UI��) =====
    public event Action<int> OnSelectedChanged;
    public event Action OnCooldownChanged;
    public event Action<bool> OnArmedChanged;

    public bool IsArmed => _armed;
    public int SelectedSlotIndex => _selectedSlotIndex;
    public ColorModuleInstance SelectedSkill => _selectedSkill;

    public int GetCooldownRemaining(int slotIndex)
        => _cooldownRemaining.TryGetValue(slotIndex, out var v) ? Mathf.Max(0, v) : 0;

    private void Awake()
    {
        if (worldCamera == null) worldCamera = Camera.main;
        if (gridBoard == null) gridBoard = FindObjectOfType<GridBoard>();
        if (fieldTimeManager == null) fieldTimeManager = FieldTimeManager.Instance ?? FindObjectOfType<FieldTimeManager>();
        if (playerStats == null) playerStats = FindObjectOfType<PlayerStats>();
        if (moduleSlots == null) moduleSlots = ColorModuleSlots.Instance;
    }

    private void OnEnable()
    {
        if (fieldTimeManager == null)
            fieldTimeManager = FieldTimeManager.Instance ?? FindObjectOfType<FieldTimeManager>();
        if (fieldTimeManager != null)
            fieldTimeManager.OnTimeAdvanced += HandleTimeAdvanced;
    }

    private void OnDisable()
    {
        if (fieldTimeManager != null)
            fieldTimeManager.OnTimeAdvanced -= HandleTimeAdvanced;
    }

    private void HandleTimeAdvanced(int delta, int newTotalTime)
    {
        bool changed = false;
        var keys = new List<int>(_cooldownRemaining.Keys);
        foreach (int key in keys)
        {
            if (_cooldownRemaining[key] > 0)
            {
                _cooldownRemaining[key] = Mathf.Max(0, _cooldownRemaining[key] - Mathf.Max(1, delta));
                changed = true;
            }
        }
        if (changed) OnCooldownChanged?.Invoke();
    }

    private void Update()
    {
        if (_isCasting) return;
        if (gridBoard == null || moduleSlots == null) return;

        // �������� ���̸� �ʵ� ��ų ��Ȱ��ȭ
        var focusedCombat = FocusedCombatManager.Instance;
        if (focusedCombat != null && focusedCombat.IsInFocusedCombat) return;

        // ����Ű 1~5 = ������ ��ų ����
        var skills = moduleSlots.GetEquippedSkills();
        for (int i = 0; i < skills.Count && i < 5; i++)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1 + i))
            {
                SelectSkill(i, skills[i]);
                break;
            }
        }

        // ESC / ��Ŭ�� = ����
        if (_armed)
        {
            if (Input.GetKeyDown(KeyCode.Escape) || Input.GetMouseButtonDown(1))
            {
                Disarm();
                return;
            }
        }

        // ��Ŭ�� = ����
        if (_armed && Input.GetMouseButtonDown(0))
        {
            if (!TryGetMouseCell(out Vector2Int cell))
                return;

            TryCastSkill(cell);
        }
    }

    // ===== Select / Disarm =====

    public void SelectSkill(int index, ColorModuleInstance skill)
    {
        if (skill == null) return;

        // ��ٿ� üũ
        if (GetCooldownRemaining(index) > 0)
        {
            if (log) Debug.Log($"[FieldSkill] ��ٿ� ��! ���� ��: {GetCooldownRemaining(index)}");
            return;
        }

        // ���� ��ų �ٽ� ������ ���
        if (_armed && _selectedSlotIndex == index)
        {
            Disarm();
            return;
        }

        _selectedSlotIndex = index;
        _selectedSkill = skill;
        SetArmed(true);
        OnSelectedChanged?.Invoke(index);

        if (log) Debug.Log($"[FieldSkill] {skill.Name} ����! ����� Ŭ���ϼ���.");
    }

    public void Disarm()
    {
        if (!_armed) return;
        _selectedSkill = null;
        _selectedSlotIndex = -1;
        SetArmed(false);
        if (log) Debug.Log("[FieldSkill] ��ų ����");
    }

    private void SetArmed(bool armed)
    {
        if (_armed == armed) return;
        _armed = armed;
        OnArmedChanged?.Invoke(_armed);
    }

    // ===== Cast =====

    private void TryCastSkill(Vector2Int targetCell)
    {
        if (_selectedSkill == null) return;

        Vector2Int pCell = gridBoard.WorldToCell(transform.position);
        int range = _selectedSkill.definition != null ? _selectedSkill.definition.range : 1;

        // === �þ���˼� (�̵���) ===
        if (_selectedSkill.Skill == SkillID.Blue_StretchTentacle)
        {
            if (targetCell == pCell) return;

            int dist = Chebyshev(pCell, targetCell);
            if (dist > 3)
            {
                if (log) Debug.Log("[FieldSkill] 3ĭ �ʰ�!");
                return;
            }
            if (gridBoard.IsMoveBlocked(targetCell))
            {
                if (log) Debug.Log("[FieldSkill] �̵� �Ұ� ����!");
                return;
            }

            StartCoroutine(FieldMoveSkillRoutine(targetCell));
            return;
        }

        // === ��¡�ϴ��˼� (�ڱ� ����) ===
        if (_selectedSkill.Skill == SkillID.Black_PunishingTentacle)
        {
            StartCoroutine(FieldSelfBuffRoutine());
            return;
        }

        // === ���� ��ų ===
        // ���� ���� �ִ��� Ȯ��
        if (!TryGetEnemyOnCell(targetCell, out EnemyInstance targetEnemy))
        {
            if (log) Debug.Log("[FieldSkill] ���� ���� Ÿ��!");
            return;
        }

        int attackDist = Chebyshev(pCell, targetCell);
        if (attackDist > range)
        {
            if (log) Debug.Log($"[FieldSkill] ��Ÿ� ��! �Ÿ�: {attackDist}, ��Ÿ�: {range}");
            return;
        }

        if (requireLoS && !FieldCombatUtils.HasLineOfSight(gridBoard, pCell, targetCell))
        {
            if (log) Debug.Log("[FieldSkill] �þ� ����!");
            return;
        }

        StartCoroutine(FieldAttackSkillRoutine(targetCell, targetEnemy));
    }

    // ============================================
    // ���� ��ų ����
    // ============================================
    private IEnumerator FieldAttackSkillRoutine(Vector2Int targetCell, EnemyInstance enemy)
    {
        _isCasting = true;
        ColorModuleInstance skill = _selectedSkill;
        int slotIdx = _selectedSlotIndex;

        // ��� ����
        Vector3 start = transform.position;
        Vector3 target = gridBoard.CellToWorld(targetCell);
        Vector3 dir = target - start;
        if (dir.sqrMagnitude > 0.0001f)
        {
            Vector3 dashPos = start + dir * castDashFraction;
            yield return SmoothMove(transform, start, dashPos, castDashDuration);
            yield return SmoothMove(transform, dashPos, start, castReturnDuration);
        }

        // �нú� ATK ���� ���
        var skillExec = ColorSkillExecutor.Instance;
        float passiveMultiplier = 1f;
        if (skillExec != null)
        {
            int enemyStatusCount = 0; // �ʵ� ���� StatusEffectManager�� ���� �� ����
            var enemySE = enemy.GetComponent<StatusEffectManager>();
            if (enemySE != null) enemyStatusCount = enemySE.TotalEffectCount;

            int enemyMaxHP = enemy.definition != null ? enemy.definition.maxHP : enemy.currentHP;
            passiveMultiplier = skillExec.CalculatePassiveATKMultiplier(
                playerStats.hp, playerStats.maxHP,
                enemy.currentHP, enemyMaxHP,
                enemyStatusCount
            );
        }

        // �⺻ ������ ���
        int baseDamage = Mathf.RoundToInt(playerStats.ATK * passiveMultiplier);
        int bonusDamage = 0;

        // �� StatusEffectManager (������ �߰�)
        var enemyStatus = enemy.GetComponent<StatusEffectManager>();
        if (enemyStatus == null)
            enemyStatus = enemy.gameObject.AddComponent<StatusEffectManager>();

        // === ��ų�� ȿ�� ===
        switch (skill.Skill)
        {
            case SkillID.Red_SharpTentacle:
                // ��ī�ο��˼�: ���� �ο�, �̹� �����̸� ATK 40% �߰�
                if (enemyStatus.HasEffect(StatusEffectType.Bleeding))
                    bonusDamage = Mathf.RoundToInt(playerStats.ATK * 0.4f);
                enemy.TakeDamage(baseDamage + bonusDamage);
                enemyStatus.ApplyBleeding();
                if (log) Debug.Log($"[FieldSkill] ��ī�ο��˼�: {baseDamage + bonusDamage} ����, ���� �ο�");
                break;

            case SkillID.Red_PiercingTentacle:
                // �İ�����˼�: ���� �ο�, �̹� �����̸� 50% ȸ��
                bool wasBleeding = enemyStatus.HasEffect(StatusEffectType.Bleeding);
                int dmg = baseDamage;
                enemy.TakeDamage(dmg);
                if (wasBleeding && dmg > 0)
                {
                    int heal = Mathf.RoundToInt(dmg * 0.5f);
                    playerStats.Heal(heal);
                    if (log) Debug.Log($"[FieldSkill] �İ�����˼�: {heal} ȸ��!");
                }
                enemyStatus.ApplyBleeding();
                if (log) Debug.Log($"[FieldSkill] �İ�����˼�: {dmg} ����, ���� �ο�");
                break;

            case SkillID.Blue_HardTentacle:
                // �ܴ����˼�: �ҿ��� �ο�
                enemy.TakeDamage(baseDamage);
                enemyStatus.ApplyImperfect(1);
                int stacks = enemyStatus.GetImperfectStacks();
                if (log) Debug.Log($"[FieldSkill] �ܴ����˼�: {baseDamage} ����, �ҿ��� {stacks}��ø");
                break;

            case SkillID.Black_DeadlyTentacle:
                // ġ�������˼�: ù ���� Ȯ�� ġ��Ÿ
                bool isFirst = !skill.firstStrikeUsedOn.Contains(enemy.transform);
                int critDmg = baseDamage;
                if (isFirst)
                {
                    critDmg = Mathf.RoundToInt(critDmg * playerStats.CRIT_DMG);
                    skill.firstStrikeUsedOn.Add(enemy.transform);
                    if (log) Debug.Log($"[FieldSkill] ġ�������˼�: Ȯ�� ġ��Ÿ! {critDmg} ����");
                }
                else
                {
                    if (log) Debug.Log($"[FieldSkill] ġ�������˼�: {critDmg} ����");
                }
                enemy.TakeDamage(critDmg);
                break;

            default:
                enemy.TakeDamage(baseDamage);
                if (log) Debug.Log($"[FieldSkill] {skill.Name}: {baseDamage} ����");
                break;
        }

        // === �нú� ��ó�� ===
        // ����: �� HP 20% ���� ó��
        if (skillExec != null && enemy.currentHP > 0)
        {
            int enemyMaxHP = enemy.definition != null ? enemy.definition.maxHP : enemy.currentHP;
            if (skillExec.CheckPredation(enemy.currentHP, enemyMaxHP, out int healAmt))
            {
                int remaining = enemy.currentHP;
                enemy.TakeDamage(remaining);
                playerStats.Heal(remaining);
                if (log) Debug.Log($"[FieldSkill] ���� ó��! {remaining} ȸ��!");
            }
        }

        // �˼���ȭ: 25% Ȯ�� ����
        if (skillExec != null && skillExec.CheckStunOnHit() && enemy.currentHP > 0)
        {
            enemyStatus.TryApplyStun(transform);
            if (log) Debug.Log("[FieldSkill] �˼���ȭ: ����!");
        }

        // �⺻��: 25% Ȯ�� 2ȸ ����
        if (skillExec != null && skillExec.CheckDoubleAttack() && enemy.currentHP > 0)
        {
            int extraDmg = Mathf.RoundToInt(playerStats.ATK * passiveMultiplier);
            enemy.TakeDamage(extraDmg);
            if (log) Debug.Log($"[FieldSkill] �⺻�� 2ȸ ����! �߰� {extraDmg} ����");

            // �߰� ���ݿ��� �˼���ȭ üũ
            if (skillExec.CheckStunOnHit() && enemy.currentHP > 0)
            {
                enemyStatus.TryApplyStun(transform);
                if (log) Debug.Log("[FieldSkill] �⺻��+�˼���ȭ: �߰� ����!");
            }
        }

        // ��ٿ� (AP ��븸ŭ �� ��ٿ�)
        if (skill.APCost >= 2)
        {
            _cooldownRemaining[slotIdx] = skill.APCost;
            OnCooldownChanged?.Invoke();
        }

        // �� �Һ� + �� �ݰ�
        FinishFieldAction();

        Disarm();
        _isCasting = false;
    }

    // ============================================
    // �̵� ��ų (�þ���˼�)
    // ============================================
    private IEnumerator FieldMoveSkillRoutine(Vector2Int targetCell)
    {
        _isCasting = true;
        int slotIdx = _selectedSlotIndex;

        // �̵�
        Vector3 targetPos = gridBoard.CellToWorld(targetCell);
        yield return SmoothMove(transform, transform.position, targetPos, 0.15f);
        transform.position = targetPos;

        // GridOccupancy ����
        var occupancy = GridOccupancyRegistry.Instance;
        if (occupancy != null)
        {
            occupancy.Release(transform);
            occupancy.TryOccupy(transform, targetCell);
        }

        // PlayerGridMover ����ȭ
        var mover = GetComponent<PlayerGridMover>();
        if (mover != null)
            mover.SetCurrentCell(targetCell);

        // ��ٿ� (AP ��븸ŭ)
        if (_selectedSkill != null && _selectedSkill.APCost >= 2)
        {
            _cooldownRemaining[slotIdx] = _selectedSkill.APCost;
            OnCooldownChanged?.Invoke();
        }

        if (log) Debug.Log($"[FieldSkill] �þ���˼�: {targetCell}�� �̵�!");

        // �� �Һ� + �� �ݰ�
        FinishFieldAction();

        Disarm();
        _isCasting = false;
    }

    // ============================================
    // �ڱ� ���� (��¡�ϴ��˼�)
    // ============================================
    private IEnumerator FieldSelfBuffRoutine()
    {
        _isCasting = true;
        int slotIdx = _selectedSlotIndex;

        _selectedSkill.punishingBuffNextAttack = 1;
        if (log) Debug.Log("[FieldSkill] ��¡�ϴ��˼�: ���� ���� �� 1.75��!");

        // ��ٿ� (AP ��븸ŭ)
        if (_selectedSkill != null && _selectedSkill.APCost >= 2)
        {
            _cooldownRemaining[slotIdx] = _selectedSkill.APCost;
            OnCooldownChanged?.Invoke();
        }

        yield return new WaitForSeconds(0.2f);

        // �� �Һ� + �� �ݰ�
        FinishFieldAction();

        Disarm();
        _isCasting = false;
    }

    // ============================================
    // ����: �� �Һ� + �� �ݰ�
    // ============================================
    private void FinishFieldAction()
    {
        // Time 1 �Һ�
        if (fieldTimeManager != null)
            fieldTimeManager.Advance(1);

        // ���� �ݰ�
        FieldMultiEnemyAttack multiAttack = FindObjectOfType<FieldMultiEnemyAttack>();
        if (multiAttack != null)
            multiAttack.OnPlayerTurnEnd();
    }

    // ============================================
    // ��ƿ
    // ============================================
    private bool TryGetMouseCell(out Vector2Int cell)
    {
        cell = default;
        if (worldCamera == null || gridBoard == null) return false;
        Vector3 w = worldCamera.ScreenToWorldPoint(Input.mousePosition);
        w.z = 0f;
        cell = gridBoard.WorldToCell(w);
        return true;
    }

    private bool TryGetEnemyOnCell(Vector2Int cell, out EnemyInstance enemy)
    {
        enemy = null;
        Vector3 w = gridBoard.CellToWorld(cell);
        Vector2 wp = new Vector2(w.x, w.y);

        Collider2D[] hits = Physics2D.OverlapCircleAll(wp, cellOverlapRadius, enemyQueryLayerMask);
        if (hits == null || hits.Length == 0) return false;

        for (int i = 0; i < hits.Length; i++)
        {
            var inst = hits[i].GetComponentInParent<EnemyInstance>();
            if (inst == null || inst.currentHP <= 0) continue;
            enemy = inst;
            return true;
        }
        return false;
    }

    private int Chebyshev(Vector2Int a, Vector2Int b)
    {
        return Mathf.Max(Mathf.Abs(a.x - b.x), Mathf.Abs(a.y - b.y));
    }

    private static IEnumerator SmoothMove(Transform tf, Vector3 from, Vector3 to, float duration)
    {
        if (tf == null) yield break;
        if (duration <= 0f) { tf.position = to; yield break; }

        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / duration;
            tf.position = Vector3.Lerp(from, to, Mathf.Clamp01(t));
            yield return null;
        }
        tf.position = to;
    }
}