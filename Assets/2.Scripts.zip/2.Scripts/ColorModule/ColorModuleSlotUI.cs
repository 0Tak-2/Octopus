using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

/// <summary>
/// 개별 색 모듈 슬롯 UI
/// </summary>
public class ColorModuleSlotUI : MonoBehaviour,
    IPointerClickHandler, IBeginDragHandler, IDragHandler, IEndDragHandler, IDropHandler
{
    [Header("UI Elements")]
    public Image iconImage;
    public Image backgroundImage;
    public TMP_Text nameText;
    public TMP_Text apCostText;
    public GameObject emptyIndicator;

    [Header("Colors")]
    public Color emptyColor = new Color(0.3f, 0.3f, 0.3f, 0.5f);
    public Color redColor = new Color(1f, 0.3f, 0.3f, 0.8f);
    public Color blueColor = new Color(0.3f, 0.3f, 1f, 0.8f);
    public Color blackColor = new Color(0.2f, 0.2f, 0.2f, 0.8f);

    private ColorModuleInstance _module;
    private int _slotIndex = -1;

    public ColorModuleInstance Module => _module;
    public int SlotIndex => _slotIndex;

    public void SetSlotIndex(int index)
    {
        _slotIndex = index;
    }

    public void SetModule(ColorModuleInstance module)
    {
        _module = module;
        Refresh();
    }

    public void Refresh()
    {
        if (_module == null || _module.definition == null)
        {
            // 빈 슬롯
            if (iconImage != null) iconImage.enabled = false;
            if (nameText != null) nameText.text = "";
            if (apCostText != null) apCostText.text = "";
            if (emptyIndicator != null) emptyIndicator.SetActive(true);
            if (backgroundImage != null) backgroundImage.color = emptyColor;
        }
        else
        {
            // 모듈 있음
            if (iconImage != null)
            {
                if (_module.Icon != null)
                {
                    iconImage.sprite = _module.Icon;
                    iconImage.enabled = true;
                }
                else
                {
                    iconImage.enabled = false;
                }
            }

            if (nameText != null)
                nameText.text = !string.IsNullOrEmpty(_module.definition?.nameKey)
                    ? LocalizationManager.T(_module.definition.nameKey) : _module.Name;

            if (apCostText != null)
            {
                if (_module.Type == ModuleType.Skill)
                    apCostText.text = $"AP {_module.APCost}";
                else
                    apCostText.text = LocalizationManager.T("UI_PASSIVE");
            }

            if (emptyIndicator != null)
                emptyIndicator.SetActive(false);

            if (backgroundImage != null)
            {
                backgroundImage.color = _module.Color switch
                {
                    ColorType.Red => redColor,
                    ColorType.Blue => blueColor,
                    ColorType.Black => blackColor,
                    _ => emptyColor
                };
            }
        }
    }

    public void OnPointerClick(PointerEventData eventData)  
    {
        if (!eventData.eligibleForClick) return;
        if (ColorModuleUI.Instance == null) return;

        if (eventData.button == PointerEventData.InputButton.Left)
        {
            ColorModuleUI.Instance.OnSlotClicked(_slotIndex);
        }
        else if (eventData.button == PointerEventData.InputButton.Right)
        {
            ColorModuleUI.Instance.OnSlotRightClicked(_slotIndex);
        }
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (_module == null || _slotIndex < 0) return;
        InventoryDragSession.BeginColorModuleSlot(_slotIndex);

        if (iconImage != null && iconImage.sprite != null)
        {
            Canvas c = GetComponentInParent<Canvas>();
            if (c != null)
            {
                GameObject g = new GameObject("ModDragGhost");
                g.transform.SetParent(c.transform, false);
                g.transform.SetAsLastSibling();
                var img = g.AddComponent<Image>();
                img.sprite = iconImage.sprite;
                img.raycastTarget = false;
                img.preserveAspect = true;
                var rt = g.GetComponent<RectTransform>();
                rt.sizeDelta = iconImage.rectTransform.rect.size;
                InventoryDragSession.DragGhost = g;
            }
        }
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (InventoryDragSession.DragGhost != null)
            InventoryDragSession.DragGhost.transform.position = eventData.position;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        InventoryDragSession.Clear();
    }

    public void OnDrop(PointerEventData eventData)
    {
        if (_slotIndex < 0) return;
        if (InventoryDragResolver.TryDropOnColorModuleSlot(_slotIndex))
            InventoryDragSession.Clear();
    }
}