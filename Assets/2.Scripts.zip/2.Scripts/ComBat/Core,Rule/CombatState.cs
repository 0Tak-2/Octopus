using UnityEngine;

[System.Serializable]
public class CombatState
{
    public bool isInCombat;
    public bool isPlayerTurn;
    public bool isBusy;

    public Vector2Int playerCell;
    public Vector2Int enemyCell;

    public int playerHP;
    public int enemyHP;

    public int currentAP;
    public int maxAP;
    public int startAP;

    // ���� �̵� ��� Ƚ��(�ط��� 2ȸ ����)
    public int freeMovesUsedThisTurn;

    public void ResetTurn()
    {
        freeMovesUsedThisTurn = 0;
    }
}
