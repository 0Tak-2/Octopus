using UnityEngine;

public class CombatUnitStats : MonoBehaviour
{
    [Header("Base")]
    public int baseFreeMovesPerTurn = 1;   // ����: �ϴ� ���� �̵� 1ȸ
    [Range(0f, 1f)]
    public float baseEvasion = 0f;         // �⺻ ȸ����(0~1)

    [Header("Terrain Bonuses (runtime)")]
    public int freeMovesBonus = 0;         // �ط�: +1
    public int rangeBonus = 0;             // ���: +1
    public float evasionBonus = 0f;        // ����: +0.40

    public int FreeMovesPerTurn => Mathf.Max(0, baseFreeMovesPerTurn + freeMovesBonus);
    public float Evasion => Mathf.Clamp01(baseEvasion + evasionBonus);

    public void ClearTerrainBonuses()
    {
        freeMovesBonus = 0;
        rangeBonus = 0;
        evasionBonus = 0f;
    }
}
